var common = {
	make2Darray : function(len){
		var a = [];
		while(a.push([]) < len); 
		return a;
	}
}

var board = {
	turn : 'blue',
	col : 0,
	win : false,
	animating : false,
	quatro : [],
	arr : common.make2Darray(8),
	handle : $('<div>').attr('id','handle').append('<b><b></b></b>'),
	
	init : function(container){
		this.table = this.makeBoard();
		this.handle.addClass( board.turn ).appendTo(this.table);
		this.userEvents();
		container.append(this.table);
	},

	make2Darray : function(len){
		var a = [];
		while(a.push([]) < len); 
		return a;
	},
	
	makeBoard : function(){
		var cols, rows, col,
			board = $('<div>').addClass('board');
		for( cols=8; cols--; ){
			col = $('<aside>').appendTo(board);
			for( rows=8; rows--; ){
				$('<div>').appendTo(col).data('index',7-cols+''+rows);
			}
		}
		return board;
	},
	
	userEvents : function(){
		var that = this,
			asides = $(this.table).find('aside');
		
		$(this.table)
			.delegate('div', 'click', userInput_mouseclick )
			.delegate('aside', 'mouseover', moveHandle );
			
		function userInput_mouseclick(e){

			if( that.win )
				return;

			var col, row, move;
			col = $(e.currentTarget).data('index')[0]|0;
			row = 7 - that.arr[col].length;

			that.makeMove(row,col);
		}
		
		function moveHandle(e){
			var col = that.col = asides.index( $(this) );
			board.handle.css('left', col*51 );
		}
	},

	makeMove : function(row,col){
		var that = this, cell, position, duration;

		if( this.arr[col].length == 8 ){
			return false;
		}

		if(this.win){
			this.cleanWinMessage();
		}

		this.arr[col].push(this.turn);

		that.handle.hide();
		
		cell = that.table.find('aside').eq(col).find('div').eq(row);
		cell.addClass(that.turn).append('<b><b></b></b>');

		if( that.checkWin(7-row, col) )
			that.gameOver();
		else{
			that.handle.show().css({top:'-55px', left:that.col*51});
			that.changeTurn();
		}
	},

	changeTurn : function(){
		this.turn = this.handle[0].className = this.turn == 'red' ? 'blue' : 'red';
	},

	checkWin : function(r, c){
		var arr = this.arr,
			quatro = [],
			i, j, victory = false;

		function checkRow(){
			quatro.length = 0;
			for( i=0; i<7; i++ ){

				if( arr[i][r] && arr[i+1][r] && arr[i][r] == arr[i+1][r] ){
					quatro.push( i+""+r );
					if( quatro.length == 3 )
						quatro.push( i+1+""+r );
				}
				else
					quatro.length = 0;
				
				if( quatro.length == 4 ){
					multiWin(quatro);
					return true;
				}
			}
			return false;
		};
		
		function checkCol(){
			quatro.length = 0;
			for( i=0; i < arr[c].length; i++ ){
				if( arr[c][i] == arr[c][i+1] ){
					quatro.push( c+""+i );
					if( quatro.length == 3 )
						quatro.push( c+""+(i+1) );
				}
				else
					quatro.length = 0;

				if( quatro.length == 4 ){
					multiWin(quatro);
					return true;
				}
			}
			return false;
		};
		
		function multiWin(quatro){
			board.quatro = board.quatro.concat(quatro); 
		};

		if( checkRow() )
			victory = true;
		if( checkCol() )
			victory = true;
		
		return victory;
	},
	
	gameOver : function(){
		var letters, tiles,row,col
			that = this;
		console.warn(this.turn,'wins');

		this.showWinMessage();
	},

	cleanWinMessage : function(){
		var that = this;

		for(col = 0; col<8; col++){
			that.table.find('aside').eq(col).find('div').eq(2).html('');
		}
	},

	showWinMessage : function(){
		var that = this;

		if(this.turn == "red"){
			letters = ['','R','E','D','','W','O','N'];
		}
		else{
			letters = ['B','L','U','E','','W','O','N'];
		}

		that.handle.hide();
		
		for(row = 0; row<8; row++){
			for(col = 0; col<8; col++){
					cell = that.table.find('aside').eq(col).find('div').eq(2);
					cell.html('').append(letters[col]);
			}
			
		}

		this.win = true;
	},

	restart : function(){
		with(board){
			arr = common.make2Darray(8)
			turn = 'blue';
			quatro.length = 0;
			win = false;
			table.find('div[class]').not('#handle').removeAttr('class').empty();
			animating = false;
			cleanWinMessage();
			handle.show();
		}
		$('#handle').stop().css('top','-55px')[0].className = board.turn;
	}
}